'use strict';

/**
 * social controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::social.social');
