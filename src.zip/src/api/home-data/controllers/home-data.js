'use strict';

/**
 * home-data controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::home-data.home-data');
